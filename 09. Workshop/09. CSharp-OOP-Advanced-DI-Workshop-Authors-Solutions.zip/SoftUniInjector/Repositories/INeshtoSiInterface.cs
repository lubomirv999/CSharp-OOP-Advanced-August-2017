﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniInjector.Repositories
{
    public interface INeshtoSiInterface
    {
        void Print();
    }
}
