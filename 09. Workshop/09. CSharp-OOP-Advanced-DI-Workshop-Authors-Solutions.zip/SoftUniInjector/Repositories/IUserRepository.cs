﻿namespace SoftUniInjector.Repositories
{
    public interface IUserRepository
    {
        void Print();
    }
}