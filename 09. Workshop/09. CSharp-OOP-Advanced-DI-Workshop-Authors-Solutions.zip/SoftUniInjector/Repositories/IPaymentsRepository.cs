﻿namespace SoftUniInjector.Repositories
{
    public interface IPaymentsRepository
    {
        void Pay();
    }
}
