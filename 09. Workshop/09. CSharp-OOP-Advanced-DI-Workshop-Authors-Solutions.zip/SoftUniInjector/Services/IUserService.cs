﻿namespace SoftUniInjector.Services
{
    public interface IUserService
    {
        void Rename();
    }
}
