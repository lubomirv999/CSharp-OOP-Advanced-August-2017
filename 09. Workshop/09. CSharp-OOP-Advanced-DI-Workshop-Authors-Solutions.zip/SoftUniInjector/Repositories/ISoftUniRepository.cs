﻿namespace SoftUniInjector.Repositories
{
    public interface ISoftUniRepository
    {
        void Oop();
    }
}
