﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniInjector.Repositories
{
    public class Useless : ISoftUniRepository
    {
        public void Oop()
        {
            Console.WriteLine("Sorry");
        }
    }
}
