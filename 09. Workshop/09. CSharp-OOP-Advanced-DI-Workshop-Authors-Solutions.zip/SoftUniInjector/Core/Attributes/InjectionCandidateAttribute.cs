﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniInjector.Core.Attributes
{
    public class InjectionCandidateAttribute : Attribute
    {
    }
}
